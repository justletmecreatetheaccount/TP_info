##########################
# DoubleLinkedList class #
##########################

"""
DoubleLinkedList represents a doubly linked list data structure, where each node has a next and previous pointer.
# @author  Kim Mens
# @version 08.12.2021 v1.2
"""

class DoubleLinkedList :
    
    def __init__(self):
        """
        Initialises a new DoubleLinkedList object, from a given list of elements lst.
        @pre:  -
        @post: A new DoubleLinkedList object has been initialised.
               __length is initalised to zero
               The first node pointer refers to None. (there is no first node yet)
               The last node pointer refers to None. (there is no last node yet)
        """
        self.__length = 0          # current length of the linked list
        self.__head = None         # pointer to the first node in the list
        self.__last = None         # pointer to the last node in the list
            
    def size(self):
        """
        Returns the number of nodes contained in this DoubleLinkedList.
        @pre:  -
        @post: Returns the number of nodes (possibly zero) contained in this linked list.
        """
        return self.__length

    def first(self):
        """Returns the first node of this DoubleLinkedList.
        @pre:  -
        @post: Returns a reference to the head of this DoubleLinkedList,
               or None if the linked list contains no nodes.
        """
        return self.__head
        
    def last(self):
        """Returns the last node of this DoubleLinkedList.
        @pre:  -
        @post: Returns a reference to the last node of this DoubleLinkedList,
               or None if the linked list contains no nodes.
        """
        return self.__last

    def add_to_start(self, cargo):
        """ 
        Adds a new DoubleNode with given cargo to the front of this DoubleLinkedList. 
        @pre: self is a (possibly empty) DoubleLinkedList.
        @post: A new DoubleNode object is created with the given cargo.
               The new DoubleNode's next pointer points to the previous head of the list.
               The new DoubleNode's prev pointer points to None. 
               The head of the list now points to this new DoubleNode.
               If the list was previously empty, its last pointer now points to this new DoubleNode as well.
               The prev pointer of the DoubleNode which was the previous head now points to the new DoubleNode. 
               The length counter has been incremented by 1.
        """
        nxt =  self.first()
        prv =  None
        node = DoubleNode(cargo,nxt,prv)
        if self.size() == 0 :           # When this is the first element being added,
            self.__last = node          # set the last pointer to this new node
        else :                          # if there was already a first node before, 
            nxt.set_prev(node)  # set previous pointer of the next node to the new node
        self.__head = node
        self.__length += 1

    def add_to_end(self, cargo):
        """ 
        Adds a new DoubleNode with given cargo to the end of this DoubleLinkedList. 
        @pre: self is a (possibly empty) DoubleLinkedList.
        @post: A new DoubleNode object is created with the given cargo.
               The new DoubleNode's next pointer points to None.
               The new DoubleNode's prev pointer points to the previous last of the list. 
               The last of the list points to this new DoubleNode.
               The next pointer of the DoubleNode which was the previous last now points to the new DoubleNode
               (unless the list was previously empty). 
               If the list was previously empty, both its first and last pointer points to this new DoubleNode.
               The length counter has been incremented by 1.
        """
        if self.size() == 0 :        # if the list was previously empty,
            self.add_to_start(cargo) # adding to the end corresponds to adding at the start.
        else :
            nxt = None
            prv = self.last()
            node = DoubleNode(cargo,nxt,prv)
            prv.set_next(node)
            self.__last = node
            self.__length += 1
    
    def remove(self,node):
        """
        Deletes a given DoubleNode node from this list by reconnecting its previous to its next node, if they exist.
        @pre:  -
        @post: If the node to be removed is the only one remaining, remove it and reset the list's first
               and last pointers to None.
               If the node to be removed has a previous node, that previous node's next pointer
               now points to the node's next pointer.
               If the node to be removed has a next node, that next node's previous pointer
               now points to the node's previous pointer.
               If the node to be removed is the first of last of the list, the list's head or last
               pointers will be reset to its next or previous node, respectively.
               The list size is decremented by one.
        """
        if self.size() == 1 : # if the node to be removed is the last one remaining
            self.__head = None
            self.__last = None
        elif node is self.first() : # if the node to be removed is the head node
            self.__head = node.next()
            node.next().set_prev(None)
        elif node is self.last() : # if the node to be removed is the rear node
            self.__last = node.prev()
            node.prev().set_next(None)
        else : # the node to be removed is somewhere in the middle
            node.prev().set_next(node.next())
            node.next().set_prev(node.prev())
        self.__length -= 1

    def __str__(self):
        """
        Produces a string representing the contents of this DoubleLinkedList and its nodes.
        @pre:  self is a (possibly empty) DoubleLinkedList
        @post: Has printed a space-separated string of the form "a b c ... n",
               where "a", "b", "c", ..., "n" are the string representation of the 
               values of each of the list's nodes.
               A space is put between any two elements but not after the last.
               An empty linked is represented as "".
        """
        start = self.first()
        s = ""
        while start is not None:
            s = s + str(start.value()) + " " 
            start = start.next()
        s = s[:-1] # remove the last space
        return s

class DoubleNode:
    # Represents a doubly linked node, keeping a reference to its next and previous Node
        
    def __init__(self, cargo=None, next=None, prev=None):
        """
        Initialises a new DoubleNode object.
        @pre:  -
        @post: A new DoubleNode object has been initialised.
               A node can contain a cargo and a next and previous reference to another DoubleNode.
               If none of these are given, the node is initialised with empty cargo (None)
               and None as next and prev references.
        """
        self.__cargo = cargo
        self.__next  = next
        self.__prev  = prev

    def value(self):
        """
        @pre:  -
        @post: Returns the value of the cargo contained in this DoubleNode, or None if no cargo  was put there.
        """
        return self.__cargo

    def next(self):
        """
        Returns the next DoubleNode to which this DoubleNode refers.
        @pre:  -
        @post: Returns the DoubleNode to which this DoubleNode refers through its next pointer,
               or None if that pointer is None.
        """
        return self.__next

    def prev(self):
        """
        Returns the previous DoubleNode to which this DoubleNode refers.
        @pre:  -
        @post: Returns the DoubleNode to which this DoubleNode refers through its prev pointer,
               or None if that pointer is None.
        """
        return self.__prev

    def set_next(self,node):
        """
        Sets the next DoubleNode to which this DoubleNode refers to a new node.
        @pre:  -
        @post: The next DoubleNode to which this DoubleNode refers,
               has been set to the new DoubleNode passed as parameter.
                Can also be set to None by passing None as parameter.
        """
        self.__next = node

    def set_prev(self,node):
        """
        Sets the next DoubleNode to which this DoubleNode refers to a new node.
        @pre:  -
        @post: The previous DoubleNode to which this DoubleNode refers,
               has been set to the new DoubleNode passed as parameter.
               Can also be set to None by passing None as parameter.
        """
        self.__prev = node

    def __str__(self):
        """
        Returns a string representation of the cargo of this node.
        @pre:  -
        @post: Returns a print representation of the cargo contained in this Node.
        """
        return str(self.value())
