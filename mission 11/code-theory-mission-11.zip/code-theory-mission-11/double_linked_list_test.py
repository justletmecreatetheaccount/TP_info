###################################
# DoubleLinkedListTest test class #
###################################
"""
DoubleLinkedListTest is a unittest test class for the doubly linked list data structure class.
# @author  Kim Mens
# @version 07.12.2018 v1.1
"""

import unittest
from double_linked_list import DoubleLinkedList, DoubleNode

class DoubleLinkedListTest(unittest.TestCase) :
    
    def test_empty_list(self) :
        l = DoubleLinkedList()
        self.assertEqual(l.size(),0)
        self.assertIsNone(l.first(),None)
        self.assertIsNone(l.last(),None)

    def test_one_element_list_add_to_start(self) :
        l = DoubleLinkedList()
        l.add_to_start(1)
        self.assertEqual(l.size(),1)
        self.assertIsInstance(l.first(),DoubleNode)
        self.assertIsInstance(l.last(),DoubleNode)
        self.assertIs(l.first(),l.last())
        self.assertEqual(l.first().value(),1)
        self.assertEqual(l.last().value(),1)
        self.assertIsNone(l.first().prev())
        self.assertIsNone(l.first().next())
        self.assertIsNone(l.last().prev())
        self.assertIsNone(l.last().next())

    def test_one_element_list_add_to_end(self) :
        l = DoubleLinkedList()
        l.add_to_end(1)
        self.assertEqual(l.size(),1)
        self.assertIsInstance(l.first(),DoubleNode)
        self.assertIsInstance(l.last(),DoubleNode)
        self.assertIs(l.first(),l.last())
        self.assertIsNotNone(l.first())
        self.assertIsNotNone(l.last())
        self.assertEqual(l.first().value(),1)
        self.assertEqual(l.last().value(),1)
        self.assertIsNone(l.first().prev())
        self.assertIsNone(l.first().next())
        self.assertIsNone(l.last().prev())
        self.assertIsNone(l.last().next())

    def test_two_element_list_add_to_start(self) :
        l = DoubleLinkedList()
        l.add_to_start(2)
        l.add_to_start(1)
        self.assertEqual(l.size(),2)
        self.assertIsInstance(l.first(),DoubleNode)
        self.assertIsInstance(l.last(),DoubleNode)
        self.assertIsNotNone(l.first())
        self.assertIsNotNone(l.last())
        self.assertEqual(l.first().value(),1)
        self.assertEqual(l.last().value(),2)
        self.assertIsNot(l.first(),l.last())
        self.assertIsNone(l.first().prev())
        self.assertIsNone(l.last().next())
        self.assertIs(l.first().next(),l.last())
        self.assertIs(l.last().prev(),l.first())
        self.assertEqual(l.first().value(),1)
        self.assertIs(l.first().next().value(),2)
        self.assertIs(l.last().value(),2)
        self.assertIsNotNone(l.last().prev())
        self.assertIs(l.last().prev().value(),1)
        
    def test_two_element_list_remove(self) :
        l = DoubleLinkedList()
        l.add_to_start(2)
        l.add_to_start(1)
        self.assertEqual(l.size(),2)
        l.remove(l.first())
        self.assertEqual(l.size(),1)
        self.assertIs(l.first(),l.last())
        self.assertEqual(l.first().value(),2)
        l.remove(l.last())
        self.assertEqual(l.size(),0)
        self.assertIsNone(l.first())
        self.assertIsNone(l.last(),0)
        
if __name__ == "__main__" :
    unittest.main()
